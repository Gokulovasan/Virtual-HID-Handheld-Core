# OpenHID Handheld Framework (`Virtual-HID-Handheld-Core`)

`Virtual-HID-Handheld-Core` is an industrial-grade, zero-hardware C99 input processing engine designed to turn compact USB keyboards into fully functional virtual gamepads with relative mouse vector emulation under Linux/RetroArch ecosystems.

## Core Features
* **Virtual Gamepad Emulation:** Intercepts low-level `evdev` keypress events and outputs native Linux `uinput` virtual joystick button signals (`BTN_SOUTH`, `BTN_EAST`, `BTN_START`, etc.).
* **Virtual Mouse Pointer Control:** Translates dedicated directional key clusters (`I/J/K/L`) into relative cursor axis vectors (`REL_X`, `REL_Y`).
* **Zero Dynamic Memory Allocation:** Built strictly using stack memory and deterministic signal execution.
* **Exclusive Device Grab:** Locks the secondary keyboard input using `EVIOCGRAB` to prevent key press leakage into host terminal sessions.

## Project Structure
```
Virtual-HID-Handheld-Core/
├── CMakeLists.txt          # Build system configuration
├── include/
│   └── hid_handheld.h      # Core engine header
├── src/
│   └── main.c              # Main input interceptor entry point
└── README.md
```

## Building the Project

### Prerequisites
* GCC or Clang compiler supporting C99
* CMake (v3.14+)
* Linux kernel with `/dev/uinput` enabled

### Compilation Steps
```bash
mkdir build && cd build
cmake ..
make
```

## Usage
Find your keyboard device file under `/dev/input/event*`:
```bash
cat /proc/bus/input/devices
```

Run the engine with elevated privileges:
```bash
sudo ./virtual_hid_core /dev/input/eventX
```
